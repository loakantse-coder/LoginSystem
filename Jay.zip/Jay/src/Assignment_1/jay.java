package Assignment_1;

import javax.swing.JOptionPane;

public class jay {

    public static void main(String[] args) {

        // REGISTRATION
        String firstName = JOptionPane.showInputDialog( null, "Enter First Name:","REGISTRATION",JOptionPane.INFORMATION_MESSAGE);

        String lastName = JOptionPane.showInputDialog(null, "Enter Last Name:","REGISTRATION" ,JOptionPane.INFORMATION_MESSAGE);

        String username = JOptionPane.showInputDialog(null,"Enter Username:","REGISTRATION",JOptionPane.INFORMATION_MESSAGE);

        String password = JOptionPane.showInputDialog( null,"Enter Password:","REGISTRATION",JOptionPane.INFORMATION_MESSAGE);

        String phone = JOptionPane.showInputDialog(null,"Enter Phone Number (+27):","REGISTRATION",JOptionPane.INFORMATION_MESSAGE);

        // Login object
        Login login = new Login();

        // Validation
        boolean validUsername =login.checkUserName(username);
        boolean validPassword = login.checkPasswordComplexity(password);
        boolean validPhone =login.checkCellPhoneNumber(phone);

        // Username
        if (validUsername) {

            JOptionPane.showMessageDialog( null,"Username successfully captured.");

        } else {

            JOptionPane.showMessageDialog( null, "Username incorrectly formatted.");
        }

        // Password
        if (validPassword) {

            JOptionPane.showMessageDialog(null,"Password successfully captured.");

        } else {

            JOptionPane.showMessageDialog(null,"Password incorrectly formatted.");
        }

        // Phone
        if (validPhone) {

            JOptionPane.showMessageDialog(null,"Phone number successfully captured.");

        } else {

            JOptionPane.showMessageDialog(null,"Phone number incorrectly formatted.");
        }

        // Registration success
        if (validUsername && validPassword && validPhone) {

            JOptionPane.showMessageDialog(null,"Registration successful." );

            // LOGIN
            String enteredUsername =JOptionPane.showInputDialog(null,"Enter Username:","LOGIN",JOptionPane.INFORMATION_MESSAGE);

            String enteredPassword =JOptionPane.showInputDialog(null,"Enter Password:","LOGIN",JOptionPane.INFORMATION_MESSAGE);

            boolean loginStatus = login.loginUser(username,password,enteredUsername,enteredPassword);

            JOptionPane.showMessageDialog(null,login.returnLoginStatus(loginStatus, firstName,lastName));

            // QUICKCHAT
            if (loginStatus) {

                JOptionPane.showMessageDialog( null,"Welcome to QuickChat");

                int option = Integer.parseInt( JOptionPane.showInputDialog(
                                """
                                Choose an option:
                                
                                1) Send Messages
                                2) Show recently sent messages-Copmming soon 
                                3) Quit
                                """
                        )
                );

                switch (option) {

                    case 1:

                        int total = Integer.parseInt(
                                JOptionPane.showInputDialog(
                                        "How many messages would you like to send?"
                                )
                        );

                        for (int i = 1; i <= total; i++) {

                            String recipient =
                                    JOptionPane.showInputDialog(
                                            "Enter recipient number:"
                                    );

                            String messageText =
                                    JOptionPane.showInputDialog(
                                            "Enter message:"
                                    );

                            // Length check
                            if (messageText.length() > 250) {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Please enter a message of less than 250 characters."
                                );

                                i--;
                                continue;
                            }

                            // Create Message object
                            Message msg =
                                    new Message(
                                            i,
                                            recipient,
                                            messageText
                                    );

                            // ID validation
                            if (msg.checkMessageID()) {

                                JOptionPane.showMessageDialog(
                                        null,
                                        "Message ID successfully created."
                                );
                            }

                            // Recipient validation
                            JOptionPane.showMessageDialog(
                                    null,
                                    msg.checkRecipientCell()
                            );

                            // Message hash
                            JOptionPane.showMessageDialog(
                                    null,
                                    "Message Hash: "
                                            + msg.createMessageHash()
                            );

                            // Send/store/disregard
                            JOptionPane.showMessageDialog(
                                    null,
                                    msg.sentMessage()
                            );

                            // Print details
                            JOptionPane.showMessageDialog(
                                    null,
                                    msg.printMessages()
                            );
                        }

                        // Total messages
                        JOptionPane.showMessageDialog(
                                null,
                                "Total messages sent: "
                                        + Message.returnTotalMessages()
                        );

                        break;

                    case 2:

                        JOptionPane.showMessageDialog(
                                null,
                                "Coming Soon."
                        );

                        break;

                    case 3:

                        JOptionPane.showMessageDialog(
                                null,
                                "Goodbye."
                        );

                        System.exit(0);

                        break;

                    default:

                        JOptionPane.showMessageDialog(
                                null,
                                "Invalid option selected."
                        );
                }
            }

        } else {

            JOptionPane.showMessageDialog(
                    null,
                    "Registration failed."
            );
        }
    }
}